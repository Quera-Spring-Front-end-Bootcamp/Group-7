import {
  require_react
} from "./chunk-ST3U5LCA.js";
import "./chunk-DFKQJ226.js";
export default require_react();
//# sourceMappingURL=react.js.map
