import Img from "../../../assets/img/expandcircle.png";
import Img2 from "../../../assets/img/girl1.png";
import Img3 from "../../../assets/img/boy1.png";
import { useState } from "react";
import ListViewProject from "./ListViewProject";
const TasksViewList = () => {
  return (
    <div className="w-full h-full mt-4">
      <ListViewProject title="پروژه اول"></ListViewProject>
    </div>
  );
};

export default TasksViewList;
