import React, { createContext, useState } from 'react';

export const UserContext = createContext();

const MyProvider = ({ children }) => {

    const [loginFormState, setLoginFormState] = useState("login")

    return (
        <UserContext.Provider value={
            {
                loginFormState, setLoginFormState,
            }}>
            {children}
        </UserContext.Provider>
    );
}

export default MyProvider;
