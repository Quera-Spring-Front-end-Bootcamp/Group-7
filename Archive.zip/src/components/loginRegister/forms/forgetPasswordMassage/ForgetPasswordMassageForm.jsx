const ForgetPasswordMassageForm = () => {
  return <div>forget password massage form</div>;
};

export default ForgetPasswordMassageForm;
