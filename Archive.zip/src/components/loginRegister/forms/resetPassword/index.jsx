
const ResetPasswordForm = () => {
    return(
        <div>
            Reset Password form
        </div>
    )
}

export default ResetPasswordForm