
const TasksViewColumn = () =>{
    return(<div>
        show tasks in Column
    </div>)
}

export default TasksViewColumn