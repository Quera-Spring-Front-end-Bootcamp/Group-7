import { useState } from "react";
import persianDate from 'persian-date';

const TasksViewCalendar = () => {
    // persianDate.toLocale('fa');
    persianDate.toLocale('en');

    const daysOfWeek = persianDate.rangeName().weekdays;;
    const daysOfWeekFa = ["شنبه", "یکشنبه", "دوشنبه", "سه شنبه", "چهار شنبه", "پنج‌شنبه", "جمعه"]

    function toFarsiNumber(n) {
        const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

        return n
            .toString()
            .replace(/\d/g, x => farsiDigits[x]);
    }

    const [currentDay, setCurrentDay] = useState(new persianDate(new Date()))
    const firstDayOfMonth = new persianDate([currentDay.year(), currentDay.month(), 1]);
    const weekdayOfFirstDay = daysOfWeek.indexOf(firstDayOfMonth.format('dddd'))

    console.log(firstDayOfMonth.format());

    const firstDayOfMonthEn = new Date(firstDayOfMonth.toCalendar('gregorian').format("YYYY/M/D"))

    let currentDays = []

    console.log(weekdayOfFirstDay);
    for (let day = 0; day < 35; day++) {

        if (day === 0) {
            firstDayOfMonthEn.setDate(firstDayOfMonthEn.getDate() + (day - weekdayOfFirstDay));
        } else {
            firstDayOfMonthEn.setDate(firstDayOfMonthEn.getDate() + 1);
        }

        console.log(new persianDate(firstDayOfMonthEn).format());
        const firstDayOfMonthFa = new persianDate(firstDayOfMonthEn)

        console.log("---------", firstDayOfMonthFa);

        let calendarDay = {
            currentMonth: (firstDayOfMonthFa.format("M") === new persianDate().format("M")),
            date: firstDayOfMonthFa.format("YYYY/M/D"),
            month: firstDayOfMonthFa.format("M"),
            number: firstDayOfMonthFa.format("D"),
            selected: (firstDayOfMonthFa.format("YYYY/M/D") === currentDay.format("YYYY/M/D")),
            year: firstDayOfMonthFa.format("YYYY")
        }

        currentDays.push(calendarDay)
    }

    console.log(currentDays);

    // this.state = {
    //   currentDay: new Date()
    // }
    //   }
    // console.log(new Date(currentDay.getFullYear(), currentDay.getMonth(), 1).toLocaleDateString('fa-IR'));
    return (
        <div className="flex flex-col items-center h-[80%]">
            {/* <h1>Calendar Component</h1> */}
            <div className="w-full flex flex-row-reverse flex-wrap h-full mt-4">
                {currentDays.map((item, index) => {
                    return (
                        <>
                            {
                                index < 7 ?
                                    <div className="w-[14.24%] h-[20%] min-h-[80px] flex flex-col justify-between items-end border border-slate-200" style={item.selected ? { border: "solid 1px #208D8E" } : {}}>
                                        <p className="m-2 text-[13px]" >{daysOfWeekFa[index]}</p>
                                        <div className="w-full flex">
                                            <p className="m-2 text-[12px]" style={item.currentMonth ? {} : { opacity: "0.5" }}>{toFarsiNumber(item.number)}</p>
                                        </div>
                                    </div> :

                                    <div className="w-[14.24%] h-[20%] min-h-[80px] flex justify-start items-end border border-slate-200" style={item.selected ? { border: "solid 1px #208D8E" } : {}}>
                                        <p className="m-2 text-[12px]" style={item.currentMonth ? {} : { opacity: "0.5" }}>{toFarsiNumber(item.number)}</p>
                                    </div>
                            }
                        </>
                    )
                })}
            </div>
        </div>
    )
}

export default TasksViewCalendar