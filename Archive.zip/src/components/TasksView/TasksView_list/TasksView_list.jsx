
const TasksViewList = () =>{
    return(<div>
        show tasks in list
    </div>)
}

export default TasksViewList